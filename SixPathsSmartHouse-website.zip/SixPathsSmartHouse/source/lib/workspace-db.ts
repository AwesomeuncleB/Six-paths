import { env } from 'cloudflare:workers';
import { makeInitialData, type AppData } from './model';
export function binding() {
 if(!env.DB) throw new Error('Workspace storage is unavailable');
 return env.DB;
}
export async function readWorkspace() {
 const db=binding();
 let row=await db.prepare('SELECT data, revision FROM workspace WHERE id = ?').bind('main').first<{data:string;revision:number}>();
 if(!row){
  await db.prepare('INSERT OR IGNORE INTO workspace (id, data, revision) VALUES (?, ?, ?)').bind('main',JSON.stringify(makeInitialData()),0).run();
  row=await db.prepare('SELECT data, revision FROM workspace WHERE id = ?').bind('main').first<{data:string;revision:number}>();
 }
 if(!row)throw new Error('Workspace could not be loaded');
 return {data:JSON.parse(row.data) as AppData, revision:row.revision};
}
export async function writeWorkspace(data:AppData,revision:number) {
 const result=await binding().prepare('UPDATE workspace SET data = ?, revision = revision + 1 WHERE id = ? AND revision = ?').bind(JSON.stringify(data),'main',revision).run();
 return result.meta.changes===1;
}
